<?php
$dbuser="hotel";
$dbpass="Azure12345678";
$host="hotelserver.mysql.database.azure.com";
$db="orrsphp";
$mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?> 
