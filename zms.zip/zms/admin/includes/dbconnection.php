<?php
$con=mysqli_connect("acrss.mysql.database.azure.com", "acrss", "Azure12345678", "zmsdb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
 